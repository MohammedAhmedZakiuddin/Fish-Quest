# Fish Quest > 2023-03-29 9:28am
https://universe.roboflow.com/fish-quest/fish-quest

Provided by a Roboflow user
License: MIT

